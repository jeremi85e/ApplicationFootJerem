package com.example.applicationfootjerem;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;


public class MatchAdapter extends ArrayAdapter<Match> {

    private Context mContext;
    private List<Match> matchsList = new ArrayList<>();

    public MatchAdapter(@NonNull Context context, ArrayList<Match> list) {
        super(context, 0 , list);
        mContext = context;
        matchsList = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null)
            listItem = LayoutInflater.from(mContext).inflate(R.layout.liste_resultats_item,parent,false);

        Match currentEquipe = matchsList.get(position);

        ImageView ecussonEquipeDom = (ImageView)listItem.findViewById(R.id.ecussonEquipeDom);
        ecussonEquipeDom.setImageResource(currentEquipe.getEcussonDom());

        TextView nomEquipeDom = (TextView) listItem.findViewById(R.id.nomEquipeDom);
        nomEquipeDom.setText(currentEquipe.getNomDom());

        TextView scoreEquipeDom = (TextView) listItem.findViewById(R.id.scoreEquipeDom);
        scoreEquipeDom.setText(currentEquipe.getScoreDom());

        TextView scoreEquipeExt = (TextView) listItem.findViewById(R.id.scoreEquipeExt);
        scoreEquipeExt.setText(currentEquipe.getScoreExt());

        TextView nomEquipeExt = (TextView) listItem.findViewById(R.id.nomEquipeExt);
        nomEquipeExt.setText(currentEquipe.getNomExt());

        ImageView ecussonEquipeExt = (ImageView)listItem.findViewById(R.id.ecussonEquipeExt);
        ecussonEquipeExt.setImageResource(currentEquipe.getEcussonExt());

        return listItem;
    }
}